-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Lug 14, 2024 alle 11:10
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CulinaryCanvas`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `Composizioni`
--

CREATE TABLE `Composizioni` (
  `Ricetta` int(11) NOT NULL,
  `Ingrediente` varchar(40) NOT NULL,
  `QuantitàIngrediente` float NOT NULL,
  `UnitàMisura` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Composizioni`
--

INSERT INTO `Composizioni` (`Ricetta`, `Ingrediente`, `QuantitàIngrediente`, `UnitàMisura`) VALUES
(1, 'Guanciale', 150, 'g'),
(1, 'Pecorino', 60, 'g'),
(1, 'Peperoncino', 60, 'g'),
(1, 'Polpa di pomodoro', 700, ' ml'),
(1, 'Spaghetti', 400, 'g'),
(1, 'Vino bianco', 100, 'ml'),
(29, 'Hamburger di Scottona', 4, 'pz'),
(29, 'Olio extravergine di oliva', 40, 'ml'),
(30, 'Burro', 40, 'g'),
(30, 'Farina', 250, 'g'),
(30, 'Latte', 500, 'ml'),
(30, 'Uova', 3, 'pz'),
(32, 'Albicocca', 4, 'pz'),
(32, 'Banana', 3, 'pz'),
(32, 'Ciliegia', 10, 'pz'),
(32, 'Fragola', 8, 'pz'),
(32, 'Kiwi', 5, 'pz'),
(32, 'Limone', 1, 'pz'),
(32, 'Pesca', 2, 'pz'),
(32, 'Zucchero', 20, 'g'),
(33, 'Uova', 4, 'pz'),
(36, 'Burro', 4, 'pz');

-- --------------------------------------------------------

--
-- Struttura della tabella `Inclusioni`
--

CREATE TABLE `Inclusioni` (
  `Utente` varchar(30) NOT NULL,
  `Ingrediente` varchar(40) NOT NULL,
  `QuantitàIngrediente` float NOT NULL,
  `UnitàMisura` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Inclusioni`
--

INSERT INTO `Inclusioni` (`Utente`, `Ingrediente`, `QuantitàIngrediente`, `UnitàMisura`) VALUES
('Prova', 'Guanciale', 150, 'g'),
('Prova', 'Pecorino', 60, 'g'),
('Prova', 'Peperoncino', 60, 'g'),
('Prova', 'Polpa di pomodoro', 700, ' ml'),
('Prova', 'Spaghetti', 400, 'g'),
('Prova', 'Vino bianco', 100, 'ml'),
('Tonypino', 'Hamburger di Scottona', 4, 'pz'),
('Tonypino', 'Olio extravergine di oliva', 40, 'ml');

-- --------------------------------------------------------

--
-- Struttura della tabella `Ingredienti`
--

CREATE TABLE `Ingredienti` (
  `Nome` varchar(40) NOT NULL,
  `Categoria` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Ingredienti`
--

INSERT INTO `Ingredienti` (`Nome`, `Categoria`) VALUES
('Albicocca', 'Frutta'),
('Banana', 'Frutta'),
('Burro', 'Grassi'),
('Ciliegia', 'Frutta'),
('Farina', 'Frumenti'),
('Fragola', 'Frutta'),
('Guanciale', 'Carne'),
('Hamburger di Scottona', 'Carne'),
('Kiwi', 'Frutta'),
('Latte', 'Bevande'),
('Limone', 'Frutta'),
('Olio extravergine di oliva', 'Condimenti'),
('Pecorino', 'Formaggi'),
('Peperoncino', 'Condimenti'),
('Pesca', 'Frutta'),
('Polpa di pomodoro', 'Salse'),
('Sale', 'Condimenti'),
('Spaghetti', 'Pasta'),
('Uova', 'Uova'),
('Vino bianco', 'Bevande'),
('Zucchero', 'Condimenti');

-- --------------------------------------------------------

--
-- Struttura della tabella `Liste_della_spesa`
--

CREATE TABLE `Liste_della_spesa` (
  `Utente` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Liste_della_spesa`
--

INSERT INTO `Liste_della_spesa` (`Utente`) VALUES
('faandi'),
('Fiuum'),
('Giovanni1'),
('Prova'),
('rikspa_'),
('SantoFiumara'),
('Tonypino'),
('zVeralix_');

-- --------------------------------------------------------

--
-- Struttura della tabella `Partecipazioni`
--

CREATE TABLE `Partecipazioni` (
  `Ricetta` int(11) NOT NULL,
  `PianoAlimentare` int(11) NOT NULL,
  `Utente` varchar(30) NOT NULL,
  `TipoPasto` varchar(30) NOT NULL,
  `Giorno` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Partecipazioni`
--

INSERT INTO `Partecipazioni` (`Ricetta`, `PianoAlimentare`, `Utente`, `TipoPasto`, `Giorno`) VALUES
(1, 1, 'faandi', 'Colazione', 1),
(1, 1, 'Fiuum', 'Pranzo', 1),
(1, 1, 'Fiuum', 'Pranzo', 2),
(1, 1, 'Prova', 'Pranzo', 1),
(29, 1, 'Fiuum', 'Cena', 1),
(30, 1, 'faandi', 'Dessert', 1),
(30, 1, 'faandi', 'Colazione', 2),
(30, 1, 'Fiuum', 'Colazione', 1),
(32, 1, 'faandi', 'Cena', 1),
(32, 1, 'Fiuum', 'Snack', 1),
(33, 1, 'faandi', 'Pranzo', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `Piani_alimentari`
--

CREATE TABLE `Piani_alimentari` (
  `NumeroPiano` int(11) NOT NULL,
  `Utente` varchar(30) NOT NULL,
  `Data_inizio` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Data_fine` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Piani_alimentari`
--

INSERT INTO `Piani_alimentari` (`NumeroPiano`, `Utente`, `Data_inizio`, `Data_fine`) VALUES
(1, 'faandi', '2024-07-12 22:00:00', '2024-07-15 22:00:00'),
(1, 'Fiuum', '2024-07-22 06:00:00', '2024-07-29 06:00:00'),
(1, 'Prova', '2024-07-17 22:00:00', '2024-07-20 22:00:00'),
(1, 'rikspa_', '2024-07-12 22:00:00', '2024-07-16 22:00:00'),
(1, 'Tonypino', '2024-07-18 22:00:00', '2024-07-26 22:00:00'),
(1, 'zVeralix_', '2024-07-22 22:00:00', '2024-07-26 22:00:00');

-- --------------------------------------------------------

--
-- Struttura della tabella `Recensioni`
--

CREATE TABLE `Recensioni` (
  `Utente` varchar(30) NOT NULL,
  `Ricetta` int(11) NOT NULL,
  `Valutazione` smallint(6) NOT NULL,
  `Data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Commento` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Recensioni`
--

INSERT INTO `Recensioni` (`Utente`, `Ricetta`, `Valutazione`, `Data`, `Commento`) VALUES
('faandi', 1, 1, '2024-07-12 20:38:29', 'Troppo complessa rispetto al livello dichiarato!'),
('Fiuum', 29, 5, '2024-07-07 15:37:46', 'Molto ben curata!'),
('Fiuum', 30, 4, '2024-07-07 16:40:06', 'Buone ma da migliorare...'),
('Prova', 1, 4, '2024-07-13 13:47:01', 'Valutazione di prova'),
('SantoFiumara', 1, 5, '2024-07-12 19:32:18', 'Grandiosa ricetta, complimenti..'),
('Tonypino', 1, 3, '2024-07-10 13:30:53', ''),
('Tonypino', 29, 4, '2024-07-08 09:18:34', 'Buona ricetta, peccato per i pochi dettagli di preparazione...'),
('zVeralix_', 1, 5, '2024-07-08 11:44:55', 'BUONISSIMO!!!');

-- --------------------------------------------------------

--
-- Struttura della tabella `Ricette`
--

CREATE TABLE `Ricette` (
  `ID_Ricetta` int(11) NOT NULL,
  `Titolo` varchar(50) NOT NULL,
  `Testo` varchar(2000) NOT NULL,
  `Immagine` varchar(150) NOT NULL,
  `Difficoltà` smallint(6) NOT NULL,
  `TempoPreparazione` smallint(6) NOT NULL,
  `Porzioni` smallint(6) NOT NULL,
  `TempoCottura` smallint(6) NOT NULL,
  `ValutazioneMedia` float DEFAULT NULL,
  `DataPubblicazione` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Utente` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Ricette`
--

INSERT INTO `Ricette` (`ID_Ricetta`, `Titolo`, `Testo`, `Immagine`, `Difficoltà`, `TempoPreparazione`, `Porzioni`, `TempoCottura`, `ValutazioneMedia`, `DataPubblicazione`, `Utente`) VALUES
(1, 'Spaghetti all\'amatriciana', 'Tagliamo il guanciale a pezzetti allungati e sottili con tagliere e coltello.\r\nRosoliamo a fiamma vivace il guanciale in padella, sfumandolo con il vino quando comincia a raggrinzirsi. Lasciamo evaporare l’alcol e quando il guanciale risulta ben croccante spostiamolo in un piatto e teniamolo da parte.\r\nNel fondo di cottura del guanciale aggiungiamo il peperoncino e la polpa di pomodoro, poi lasciamo cuocere per circa 10 minuti, finché il sugo non si sarà ristretto abbastanza.\r\nMettiamo nuovamente in padella anche il guanciale e mescoliamo per fare insaporire.\r\nNel frattempo, portiamo a bollore abbondante acqua salata e cuociamo gli spaghetti al dente, poi scoliamoli e ripassiamoli a fiamma vivace per 1 minuto nella padella con il sugo.\r\nImpiattiamo la pasta e completiamo con abbondante pecorino romano grattugiato, ed ecco i nostri spaghetti all’amatriciana pronti da servire!\r\n', 'imgs/imgs_ricette/Spaghetti_alla_Amatriciana.jpg', 1, 20, 4, 10, 3.6, '2024-07-13 13:47:01', 'Fiuum'),
(29, 'Hamburger al forno', 'Spennellateli con un po\' di olio extravergine d\'oliva e infornate a 250 °C, in modalità ventilato, per 10 minuti.\r\nUna volta cotti potete servire gli hamburger al forno al piatto.', 'imgs/imgs_ricette/hamburger.jpg', 0, 10, 4, 10, 4.5, '2024-07-12 19:32:46', 'Fiuum'),
(30, 'Crepes alla Nutella', 'Per preparare le crepe dolci e salate iniziate sciogliendo dolcemente il burro in un pentolino. Lasciatelo intiepidire e nel frattempo rompete le uova in una ciotola dai bordi alti. Mescolate con una frusta e unite il latte. Continuate a mescolare sino ad ottenere un composto omogeneo.\r\nAggiungete ora il burro tiepido e mescolate ancora. Posizionate un colino sul recipiente e poi setacciate la farina nella ciotola, (per comodità potete anche aggiungerla in due tempi e mescolare così da evitare la formazione di grumi).\r\nPoi con le fruste mescolate energicamente per assorbire la farina. Continuate a mescolare fino ad ottenere un composto omogeneo, vellutato e privo di grumi. A questo punto coprite la ciotola con della pellicola alimentare e lasciate riposare per almeno 30 minuti in frigorifero.\r\n(..) Richiudete ancora a metà, in modo da ottenere un triangolo. Trasferite su un piatto, spolverizzate con zucchero a velo e servite!', 'imgs/imgs_ricette/Crepe-alla-Nutella_450x300.jpg', 0, 10, 14, 30, 4, '2024-07-12 19:32:54', 'SantoFiumara'),
(32, 'Macedonia di frutta', 'Per preparare la macedonia di frutta cominciate lavando e asciugando accuratamente la frutta. Tagliate a fette banana, kiwi, pesche, albicocche e fragole, denocciolate le ciliegie dividendole in due.\r\nRaccogliete tutta la frutta a pezzi in una ciotola capiente. Spremete il limone, scioglietevi un cucchiaio di zucchero (eviterete di avvertire fastidiosi granelli in bocca) e condite la macedonia.\r\nE il gioco è fatto!', 'imgs/imgs_ricette/macedonia.png', 0, 10, 3, 0, NULL, '2024-07-11 09:58:21', 'Tonypino'),
(33, 'Uova sode', 'Per preparare le uova sode iniziate ponendo le uova in un pentolino con acqua fredda 1; l’acqua dovrà coprire le uova. Mettete il pentolino sul fuoco e fate arrivare a bollore, poi calcolate 9 minuti di cottura a fuoco moderato 2. Trascorso questo tempo, scolate le uova e raffreddatele sotto acqua corrente oppure trasferitele in una ciotola con acqua e ghiaccio 3.\nBattete leggermente la punta sul piano di lavoro per rompere il guscio 4, poi rimuovete delicatamente il guscio 5. Le uova sode sono pronte per essere consumate come preferite 6!\nPer preparare le uova barzotte mettete sul fuoco un pentolino con l’acqua. Quando l’acqua sarà a leggero bollore inserite le uova 7 e cuocete per 6 minuti, a fuoco moderato 8. Trascorso questo tempo, scolate le uova e raffreddatele sotto acqua corrente oppure trasferitele in una ciotola con acqua e ghiaccio 9.\nBattete leggermente la punta sul piano di lavoro per rompere il guscio 10, poi rimuovete delicatamente il guscio.', 'imgs/imgs_ricette/Uova-sode_450x300.jpg', 0, 2, 4, 9, NULL, '2024-07-12 20:48:35', 'faandi'),
(36, 'Prova', 'Questa è una ricetta di prova.', 'imgs/imgs_ricette/Prova (1).jpg', 0, 10, 2, 10, NULL, '2024-07-13 14:00:33', 'Prova');

-- --------------------------------------------------------

--
-- Struttura della tabella `Utenti`
--

CREATE TABLE `Utenti` (
  `username` varchar(30) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `hashedPassword` varchar(100) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Cognome` varchar(20) NOT NULL,
  `ImmagineProfilo` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `Utenti`
--

INSERT INTO `Utenti` (`username`, `e_mail`, `hashedPassword`, `Nome`, `Cognome`, `ImmagineProfilo`) VALUES
('faandi', 'federicadiana@gmail.com', '$2a$07$usesomesillystringfore5.kSI40IQ1IY/1M3svHODU5DpmCgVpa', 'Federica ', 'Diana', 'users_uploads/Federica_pic.jpg'),
('Fiuum', 'fabiofiumara@gmail.com', '$2a$07$usesomesillystringforeKmk12epog/dbh7mshwOim6lXMcGwAWm', 'Fabio', 'Fiumara', 'users_uploads/Fabio_pic.jpg'),
('Giovanni1', 'giovannicantile@gmail.com', '$2a$07$usesomesillystringforeZ8wQICCeZ84GcLg7R9DeNYhIaWK2xYy', 'Giovanni', 'Cantile', 'users_uploads/Giovanni_pic.png'),
('Prova', 'prova@gmail.com', '$2a$07$usesomesillystringforeYjOTFMdlQ9o9Ts7zlefEvYosK1YgPdq', 'ProvaNome', 'ProvaCognome', 'users_uploads/prova.jpg'),
('rikspa_', 'riccardospagnuolo@gmail.com', '$2a$07$usesomesillystringforeQHs75TryuzInAFfsOA5IZzCd2ipo8UK', 'Riccardo', 'Spagnuolo', 'users_uploads/6345579_2.png'),
('SantoFiumara', 'santofiumara@gmail.com', '$2a$07$usesomesillystringforeQFzkFpPpRUXfjErC7vq9nAX7yvazfoG', 'Santo', 'Fiumara', 'users_uploads/Santo_pic.jpg'),
('Tonypino', 'antonioscarano@gmail.com', '$2a$07$usesomesillystringforedZrDRDqTX9HVoElSyy4ZIwK.oJ5rqha', 'Antonio', 'Scarano', 'users_uploads/young-bearded-man-with-striped-shirt_273609-5677.jpg.avif'),
('zVeralix_', 'alessiopetrillo@gmail.com', '$2a$07$usesomesillystringforegklbk0.Nxczl46et4u6ZXjhZx6kRQeS', 'Alessio', 'Petrillo', 'users_uploads/Alessio_pics.jfif');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `Composizioni`
--
ALTER TABLE `Composizioni`
  ADD PRIMARY KEY (`Ricetta`,`Ingrediente`),
  ADD KEY `Ingrediente` (`Ingrediente`);

--
-- Indici per le tabelle `Inclusioni`
--
ALTER TABLE `Inclusioni`
  ADD PRIMARY KEY (`Utente`,`Ingrediente`),
  ADD KEY `Ingrediente` (`Ingrediente`);

--
-- Indici per le tabelle `Ingredienti`
--
ALTER TABLE `Ingredienti`
  ADD PRIMARY KEY (`Nome`);

--
-- Indici per le tabelle `Liste_della_spesa`
--
ALTER TABLE `Liste_della_spesa`
  ADD PRIMARY KEY (`Utente`);

--
-- Indici per le tabelle `Partecipazioni`
--
ALTER TABLE `Partecipazioni`
  ADD PRIMARY KEY (`Ricetta`,`PianoAlimentare`,`Utente`,`Giorno`),
  ADD KEY `PianoAlimentare` (`PianoAlimentare`),
  ADD KEY `Utente` (`Utente`);

--
-- Indici per le tabelle `Piani_alimentari`
--
ALTER TABLE `Piani_alimentari`
  ADD PRIMARY KEY (`NumeroPiano`,`Utente`),
  ADD KEY `Utente` (`Utente`);

--
-- Indici per le tabelle `Recensioni`
--
ALTER TABLE `Recensioni`
  ADD PRIMARY KEY (`Utente`,`Ricetta`),
  ADD KEY `Ricetta` (`Ricetta`);

--
-- Indici per le tabelle `Ricette`
--
ALTER TABLE `Ricette`
  ADD PRIMARY KEY (`ID_Ricetta`),
  ADD KEY `Utente` (`Utente`);

--
-- Indici per le tabelle `Utenti`
--
ALTER TABLE `Utenti`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `Ricette`
--
ALTER TABLE `Ricette`
  MODIFY `ID_Ricetta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `Composizioni`
--
ALTER TABLE `Composizioni`
  ADD CONSTRAINT `composizioni_ibfk_1` FOREIGN KEY (`Ricetta`) REFERENCES `Ricette` (`ID_Ricetta`) ON DELETE CASCADE,
  ADD CONSTRAINT `composizioni_ibfk_2` FOREIGN KEY (`Ingrediente`) REFERENCES `Ingredienti` (`Nome`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Inclusioni`
--
ALTER TABLE `Inclusioni`
  ADD CONSTRAINT `inclusioni_ibfk_1` FOREIGN KEY (`Utente`) REFERENCES `Utenti` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `inclusioni_ibfk_2` FOREIGN KEY (`Ingrediente`) REFERENCES `Ingredienti` (`Nome`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Liste_della_spesa`
--
ALTER TABLE `Liste_della_spesa`
  ADD CONSTRAINT `liste_della_spesa_ibfk_1` FOREIGN KEY (`Utente`) REFERENCES `Utenti` (`username`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Partecipazioni`
--
ALTER TABLE `Partecipazioni`
  ADD CONSTRAINT `partecipazioni_ibfk_1` FOREIGN KEY (`Ricetta`) REFERENCES `Ricette` (`ID_Ricetta`) ON DELETE CASCADE,
  ADD CONSTRAINT `partecipazioni_ibfk_2` FOREIGN KEY (`PianoAlimentare`) REFERENCES `Piani_alimentari` (`NumeroPiano`) ON DELETE CASCADE,
  ADD CONSTRAINT `partecipazioni_ibfk_3` FOREIGN KEY (`Utente`) REFERENCES `Utenti` (`username`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Piani_alimentari`
--
ALTER TABLE `Piani_alimentari`
  ADD CONSTRAINT `piani_alimentari_ibfk_1` FOREIGN KEY (`Utente`) REFERENCES `Utenti` (`username`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Recensioni`
--
ALTER TABLE `Recensioni`
  ADD CONSTRAINT `recensioni_ibfk_1` FOREIGN KEY (`Utente`) REFERENCES `Utenti` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `recensioni_ibfk_2` FOREIGN KEY (`Ricetta`) REFERENCES `Ricette` (`ID_Ricetta`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Ricette`
--
ALTER TABLE `Ricette`
  ADD CONSTRAINT `ricette_ibfk_1` FOREIGN KEY (`Utente`) REFERENCES `Utenti` (`username`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
